package operators.recombinations;

import operators.Genetic;

/**
 *
 * @author Chorinca-Notebook
 */
public abstract class Recombination extends Genetic {
    
}
