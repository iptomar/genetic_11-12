/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package operators.recombinations;

import operators.Genetic;

/**
 *
 * @author Chorinca-Notebook
 */
public abstract class Recombination extends Genetic {
    
}
